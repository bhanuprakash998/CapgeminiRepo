package com.microservice.productInfo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.microservice.productInfo.dto.Product;

@Repository
public class ProductDao implements ProductDaoI {

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public Boolean addProduct(Product product) {
		if(mongoTemplate.insert(product) != null)
			return true;
		return false;
	}

	@Override
	public List<Product> getAllProducts() {
		return mongoTemplate.findAll(Product.class);
	}

	@Override
	public boolean deleteProduct(String productId) {
		Query query=new Query();
		query.addCriteria(Criteria.where("id").is(productId));
		if(mongoTemplate.findAndRemove(query,Product.class)==null) {
			return false;
		}
		return true;
	}

	@Override
	public Product getProductById(String productId) {
		Query productQuery=new Query();
		productQuery.addCriteria(Criteria.where("id").is(productId));
		return mongoTemplate.findOne(productQuery, Product.class);
	}
	
	
}
