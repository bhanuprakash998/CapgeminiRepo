package com.microservice.productInfo.service;

import java.util.List;

import com.microservice.productInfo.dto.Product;

public interface ProductServiceI {

	Boolean addProduct(Product product);

	List<Product> getAllProducts();

	boolean deleteProduct(String productId);

	Product getProductById(String productId);

}
