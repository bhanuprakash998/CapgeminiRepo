package com.microservice.rating.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import com.microservice.rating.dto.Product;
import com.microservice.rating.dto.Rating;
import com.microservice.rating.dto.User;

@Repository
public class RatingDao implements RatingDaoI{

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
	protected RestTemplate restTemplate;
	
	protected String productServiceUrl;

	public RatingDao() {	
	}
	
	public RatingDao(String productServiceUrl) {
		this.productServiceUrl = productServiceUrl.startsWith("http") ? productServiceUrl
				: "http://" + productServiceUrl;
		System.out.println(this.productServiceUrl);
	}

	@Override
	public String addRating(String email, String productId, int noOfStars, String comments) {
		User user=checkUser(email);
		if(user==null) {
			return "No user is registered with this email: "+email;
		}
		if(user.getRatings()==null) {
			user.setRatings(new ArrayList<Rating>());
		}
		Product product=restTemplate.getForObject("http://PRODUCTINFO"+"/products/getProductById?productId="+productId, Product.class);
		if(product==null) 
		{ 
			return "No product is present with this productId: "+productId;
		}
		Iterator<Rating> ratingIterator=user.getRatings().iterator();
		while(ratingIterator.hasNext()) {
			Rating rateInfo=ratingIterator.next();
			if(rateInfo.getProductId().matches(productId)) {
				return "Already Rated for this product!!";
			}
		}
		Rating rating=new Rating();
		rating.setEmail(email);
		rating.setNoOfStars(noOfStars);
		rating.setProductId(productId);
		rating.setComments(comments);
		user.getRatings().add(rating);
		mongoTemplate.save(user);
		return "Rating for the product with id: "+productId+" is done";
	}

	@Override
	public List<Rating> getAllRatingsById(String productId) {
		List<Rating> ratings=new ArrayList<Rating>();
		List<User> users=mongoTemplate.findAll(User.class);
		Iterator<User> userIterator=users.iterator();
		while(userIterator.hasNext()) {
			User user=userIterator.next();
			if(user.getRatings()!=null) {
				Iterator<Rating> ratingInfo=user.getRatings().iterator();
				while(ratingInfo.hasNext()) {
					Rating rating=ratingInfo.next();
					if(rating.getProductId().matches(productId)) {
						ratings.add(rating);
					}
				}
			}
		}
		return ratings;
	}

	@Override
	public Boolean addUser(User user) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(user.getEmail()));
		if(mongoTemplate.findOne(query,User.class)!=null) {
			return false;
		}
		mongoTemplate.insert(user);
		return true;
	}

	@Override
	public List<Rating> getAllRatings(String email) {
		User user=checkUser(email);
		if(user!=null) {
			return user.getRatings();
		}
		return null;
	}

	@Override
	public boolean forgotPassword(String userName, String securityQuestion, String securityAnswer) {
		User user=checkUser(userName);
		if(user==null)
			return false;
		if(user.getSecurityQuestion().matches(securityQuestion)){
			if(user.getSecurityAnswer().matches(securityAnswer))
				return true;
		}
		return false;
	}

	@Override
	public boolean changePassword(String userName, String password) {
		User user=checkUser(userName);
		if(user==null)
			return false;
		user.setPassword(password);
		mongoTemplate.save(user);
		return true;
	}
	
	public User checkUser(String userName) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(userName));
		return mongoTemplate.findOne(query, User.class);
	}

	@Override
	public String editRating(String email, String productId, int noOfStars, String comments) {
		User user=checkUser(email);
		boolean flag=false;
		if(user==null) {
			return "No user is registered with this email: "+email;
		}
		if(user.getRatings()==null) {
			return "No rating is done by the user :"+email+" for product Id: "+productId;
		}
		List<Rating> ratings=user.getRatings();
		Iterator<Rating> ratingIterator=ratings.iterator();
		while(ratingIterator.hasNext()) {
			Rating rateInfo=ratingIterator.next();
			if(rateInfo.getProductId().matches(productId)) {
				rateInfo.setNoOfStars(noOfStars);
				rateInfo.setComments(comments);
				flag=true;
			}
		}
		if(!flag) {
			return "Rating for product with id: "+productId+" is not found for editing...";
		}
		user.setRatings(ratings);
		mongoTemplate.save(user);
		return "Rating for the product Id: "+productId+" is edited!";
	}
}
