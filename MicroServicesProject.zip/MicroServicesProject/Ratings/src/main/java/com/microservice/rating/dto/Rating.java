package com.microservice.rating.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Rating {

	private String email;
	private int noOfStars;
	@Id
	private String productId;
	private String comments;
	public Rating(int noOfStars,String email, String comments,String productId) {
		super();
		this.email=email;
		this.noOfStars = noOfStars;
		this.comments = comments;
		this.setProductId(productId);
	}
	public Rating() {
		super();
	}
	public int getNoOfStars() {
		return noOfStars;
	}
	public void setNoOfStars(int noOfStars) {
		this.noOfStars = noOfStars;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
