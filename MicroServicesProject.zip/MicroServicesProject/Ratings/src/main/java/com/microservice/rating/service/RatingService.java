package com.microservice.rating.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.rating.dao.RatingDaoI;
import com.microservice.rating.dto.Rating;
import com.microservice.rating.dto.User;

@Service
public class RatingService implements RatingServiceI{
	
	@Autowired
	RatingDaoI ratingDao;

	@Override
	public String addRating(String email, String productId, int noOfStars, String comments) {
		return ratingDao.addRating(email,productId,noOfStars,comments);
	}

	@Override
	public List<Rating> getAllRatings(String email) {
		return ratingDao.getAllRatings(email);
	}

	@Override
	public Boolean addUser(User user) {
		return ratingDao.addUser(user);
	}

	@Override
	public List<Rating> getAllRatingsById(String productId) {
		return ratingDao.getAllRatingsById(productId);
	}

	@Override
	public boolean forgotPassword(String userName, String securityQuestion, String securityAnswer) {
		return ratingDao.forgotPassword(userName,securityQuestion,securityAnswer);
	}

	@Override
	public boolean changePassword(String userName, String password) {
		return ratingDao.changePassword(userName,password);
	}

	@Override
	public String editRating(String email, String productId, int noOfStars, String comments) {
		return ratingDao.editRating(email,productId,noOfStars,comments);
	}
}
