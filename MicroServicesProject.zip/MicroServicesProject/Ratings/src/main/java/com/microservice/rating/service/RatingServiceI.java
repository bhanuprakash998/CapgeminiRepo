package com.microservice.rating.service;

import java.util.List;

import com.microservice.rating.dto.Rating;
import com.microservice.rating.dto.User;

public interface RatingServiceI {

	String addRating(String email, String productId, int noOfStars, String comments);

	List<Rating> getAllRatings(String email);

	Boolean addUser(User user);

	List<Rating> getAllRatingsById(String productId);

	boolean forgotPassword(String userName, String securityQuestion, String securityAnswer);

	boolean changePassword(String userName, String password);

	String editRating(String email, String productId, int noOfStars, String comments);

}
