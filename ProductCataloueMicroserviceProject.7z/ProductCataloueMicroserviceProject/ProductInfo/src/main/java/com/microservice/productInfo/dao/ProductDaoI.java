package com.microservice.productInfo.dao;

import java.util.List;

import com.microservice.productInfo.dto.Product;

public interface ProductDaoI {

	Boolean addProduct(Product product);

	List<Product> getAllProducts();

	boolean deleteProduct(String productId);

	Product getProductById(String productId);

}
