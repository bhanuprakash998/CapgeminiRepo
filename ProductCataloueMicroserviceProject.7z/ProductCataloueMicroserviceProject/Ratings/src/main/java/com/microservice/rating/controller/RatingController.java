package com.microservice.rating.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.rating.dto.Rating;
import com.microservice.rating.dto.User;
import com.microservice.rating.service.RatingServiceI;

@RestController
@RequestMapping("/rating")
public class RatingController {

	@Autowired
	RatingServiceI ratingService;
	
	@PostMapping("/addUser")
	public String addUser(@RequestBody User user) {
		if(ratingService.addUser(user)) {
			return "User Profile is created";
		}
		return "Something went wrong!";
	}
	
	@GetMapping("/forgotpassword")
	public Boolean forgotPassword(@RequestParam String userName, String securityQuestion, String securityAnswer)
	{
		if(ratingService.forgotPassword(userName,securityQuestion,securityAnswer)) 
		{
			return true;
		}
		return false;
	}
	
	@GetMapping("/changepassword")
	public Boolean changePassword(@RequestParam String userName,String password){
		if(ratingService.changePassword(userName,password)) {
			return true;
		}
		return false;
	}
	
	@PostMapping("/addRating")
	public String addRating(@RequestParam String email,String password,String productId,int noOfStars,String comments) {
		return ratingService.addRating(email,password,productId,noOfStars,comments);
	}
	
	@PostMapping("/editRating")
	public String editRating(@RequestParam String email,String password, String productId, int noOfStars,String comments)
	{
		return ratingService.editRating(email,password, productId, noOfStars, comments);
	}
	
	@GetMapping("/getAllRatingsById")
	public List<Rating> getAllRatingsById(@RequestParam String productId){
		return ratingService.getAllRatingsById(productId);
	}
	
	@GetMapping("/getAllRatings")
	public List<Rating> getAllRatings(@RequestParam String email){
		return ratingService.getAllRatings(email);
	}
}
