package com.microservice.rating.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.microservice.rating.dto.Rating;

@Document
public class User {

	@Id
	private String email;
	private String name;
	private String password;
	private String address;
	private String securityQuestion;
	private String securityAnswer;
	private List<Rating> ratings;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String email, String name, String password, String address, String securityQuestion,
			String securityAnswer, List<Rating> ratings) {
		super();
		this.email = email;
		this.name = name;
		this.password = password;
		this.address = address;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
		this.ratings = ratings;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public String getSecurityAnswer() {
		return securityAnswer;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}
	public List<Rating> getRatings() {
		return ratings;
	}
	public void setRatings(List<Rating> ratings) {
		this.ratings = ratings;
	}
}
