import { Component, OnInit } from '@angular/core';
import { UnivercityService } from '../univercity.service';

@Component({
  selector: 'app-deletesingle',
  templateUrl: './deletesingle.component.html',
  styleUrls: ['./deletesingle.component.css']
})
export class DeletesingleComponent implements OnInit {
  collegedata:any[]=[];
  constructor(private uservice:UnivercityService) { }

  ngOnInit() {
    this.uservice.getCollegeDetails().subscribe((data:any)=>this.collegedata=data)
  }
onDelete(c){
  var d=this. collegedata.indexOf(c);
  this.collegedata.splice(d,1);
this.uservice.deletecollege(c).subscribe();
}
}
