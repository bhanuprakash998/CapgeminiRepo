import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { UnivercityService } from '../univercity.service';
@Component({
  selector: 'app-loadsingle',
  templateUrl: './loadsingle.component.html',
  styleUrls: ['./loadsingle.component.css']
})
export class LoadsingleComponent implements OnInit {
  course:boolean=false;
  college:boolean=false; 
   Courses:string;
  colleges:string;
  selectedtable: string = '';
  adddata:string='';
  model:any[]=[];
  constructor(private umservice:UnivercityService) { }

  ngOnInit() {
  }
  selectChangeHandler (event: any) {
    
    this.selectedtable = event.target.value;
  
    } 

    onSelect(){
      this.adddata=this.selectedtable
      
  if(this.adddata.match("colleges")){
    
    this.college=true;
    this.course=false;
    }
    else{
      this.course=true;
      this.college=false;
    }
    }

    addcollege():any{
      console.log(this.model);
      this.umservice.addcollegedetails(this.model).subscribe();
    }

    addcourse():any{
      console.log(this.model);
      this.umservice.addCourse(this.model).subscribe();
    }
    
}

