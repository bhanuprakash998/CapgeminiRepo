import { Component, OnInit } from '@angular/core';
import{Router,RouterLink} from '@angular/router'
import { UnivercityService } from '../univercity.service';
@Component({
  selector: 'app-modify',
  templateUrl: './modify.component.html',
  styleUrls: ['./modify.component.css']
})
export class ModifyComponent implements OnInit {
  router: any;
a:boolean=false;
b:boolean=true;
rowdata:any[]=[];
  collegedata:any[]=[];
  model:any={}; 
 
  constructor(private viewservice:UnivercityService) { }

  ngOnInit() {
    this.viewservice.getCollegeDetails().subscribe((data:any)=>this.collegedata=data);
    
  }
myclick(event){
  
  this.router.navigate['./oldnewnpage'];
}
  onselectnext(){
this.a=true;
this.b=false;
  }
onselect(c){
this.viewservice.searchcollege(c).subscribe((data:any)=>this.rowdata=data)
}
update(model:any){
  this.viewservice.updatecollege(model).subscribe();
}
}
