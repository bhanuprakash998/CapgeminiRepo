import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class UnivercityService {

  constructor(private http:HttpClient) { }

  getCollegeDetails(){
    return this.http.get("http://localhost:9848/college/getcollegedetails");

  }
  addcollegedetails(data:any){
     let collegedata={"sno":data.sno,"collegeCode":data.collegeCode,"collegeName":data.collegeName,
    "collegeLocation":data.collegeLocation,"affliatedDate":data.affliatedDate} 
    return this.http.post("http://localhost:9848/college/savecollege",collegedata);
  }
  searchcollege(c:any){
    return this.http.get("http://localhost:9848/college/searchcollege/"+c.sno);
  }
  updatecollege(data:any){
return this.http.post("http://localhost:9848/college/updatecollege",data);
  }

  deletecollege(c:any){
    return this.http.delete("http://localhost:9848/college/deletecollege/"+c.sno);
  }
  getCourseDetails(){
    return this.http.get("http://localhost:9848/courses/getcoursedetails")
  }

  addCourse(data:any){
    console.log(data);
   /*  private Integer courseId;
	private String courseName;
	private String courseDuration;
	private Integer noOfSems; */
    let input={"courseId":data.courseId,"courseName":data.courseName,"courseDuration":data.courseDuration,"noOfSems":data.noOfSems}
    return this.http.post("http://localhost:9848/courses/savecourses",input)
  }

}
