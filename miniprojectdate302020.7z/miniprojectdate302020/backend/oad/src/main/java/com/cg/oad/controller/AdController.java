package com.cg.oad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Feedback;
import com.cg.oad.dto.Registration;
import com.cg.oad.service.AdSeviceImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class AdController {
	
	@Autowired
	AdSeviceImpl adServiceImpl;

	
	
	@PostMapping("/register")
	public void register(@RequestBody Registration registration) {
		adServiceImpl.register(registration);
	}
	@GetMapping("/getbyId/{id}")
	public AdDetails getbyId(@PathVariable("id") String uid) {
		return adServiceImpl.getById(uid);
		
	}
	
	@GetMapping("/verifyuser/{emailId}/{password}")
	public Boolean validate(@PathVariable("emailId") String emailId, @PathVariable("password") String password) {
		return adServiceImpl.validate(emailId, password);
		
	}
	
	
	
	@PostMapping("/postad")
	public void postAd(@RequestBody AdDetails adDetails) {
		adServiceImpl.postAd(adDetails);
	}
	
	@GetMapping("/getad/{category}")
	public List<AdDetails> getdetails(@PathVariable("category") String name) {
		return adServiceImpl.getd(name);
	}
	
	@DeleteMapping("/removead/{id}")
	public void deleteAdd(@PathVariable("id") String id) {
		adServiceImpl.deleteAdd(id);
	}
	@PutMapping("/update")
	public void update(@RequestBody AdDetails adDetails) {
	adServiceImpl.update(adDetails);
	}
	@GetMapping("/getall")
	public List<AdDetails> GetAll()
	{
		return adServiceImpl.GetAll();
	}
	@PostMapping("/reportad/{id}/{desc}")
	public void PostData(@PathVariable("id") String id, @PathVariable("desc") String desc)
	{
		System.out.println("in c");
		adServiceImpl.PostReport(id,desc);
	}
	
}
