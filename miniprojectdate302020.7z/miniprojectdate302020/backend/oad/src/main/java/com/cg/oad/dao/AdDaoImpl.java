package com.cg.oad.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Feedback;
import com.cg.oad.dto.Registration;

@Repository
public class AdDaoImpl implements AdDaoI{

	@Autowired
	MongoTemplate mongoTemplate;
	
	
	
	
	
	
	@Override
	public void register(Registration registration) {
		mongoTemplate.save(registration);
		
	}
	
	
	@Override
	public Boolean validate(String mail, String password) {
		List<Registration> userDetails=mongoTemplate.findAll(Registration.class);
		for (Registration registration : userDetails) {
			if(registration.getEmailId().equals(mail)&& registration.getPassword().equals(password))
				return true;
		
		}
		return false;
	}
	
	
	
	
	
	@Override
	public void postAd(AdDetails adDetails) {
		
		
		mongoTemplate.save(adDetails);
		
	}

	@Override
	public List<AdDetails> getd(String name) {
		List<AdDetails> details= mongoTemplate.findAll(AdDetails.class);
		List<AdDetails> result=new ArrayList<>();
		for (AdDetails adDetails : details) {
			if(adDetails.getCategory().equals(name)||adDetails.getName().equals(name))
			{
				
				result.add(adDetails);
			}
			
		}
			
		return result;
	}
	


	
	
	@Override
	public void deleteAdd(String id) {
		List<AdDetails> details=mongoTemplate.findAll(AdDetails.class);
		for (AdDetails adDetails2 : details) {
			if(adDetails2.getGenUniqId().equals(id))
		
		
		mongoTemplate.remove(adDetails2);
		}
		
	}


	@Override
	public void update(AdDetails adDetails) {
		// TODO Auto-generated method stub
		AdDetails object=mongoTemplate.findById(adDetails.getGenUniqId(),AdDetails.class);
		deleteAdd(adDetails.getGenUniqId());
		object.setCategory(adDetails.getCategory());
		object.setContactNo(adDetails.getContactNo());
		object.setDescription(adDetails.getDescription());
		object.setEmailId(adDetails.getEmailId());
		object.setGenUniqId(adDetails.getGenUniqId());
		object.setName(adDetails.getName());
		object.setPrice(adDetails.getPrice());
		mongoTemplate.insert(object);
		
		
	}


	@Override
	public List<AdDetails> GetAll() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(AdDetails.class);
	}


	


	


	@Override
	public void PostReport(String id, String desc) {
		// TODO Auto-generated method stub
		List<AdDetails> result=mongoTemplate.findAll(AdDetails.class);
		insertReport(id, desc);
		
	}


	


	@Override
	public void insertReport(String id, String desc) {
		// TODO Auto-generated method stub
		Feedback fd=new Feedback();
		fd.setuId(id);
		fd.setDescription(desc);
		System.out.println("in dao"+fd);
		mongoTemplate.save(fd);
		
		
		
	}


	@Override
	public AdDetails getById(String id) {
		// TODO Auto-generated method stub
		List<AdDetails> details= mongoTemplate.findAll(AdDetails.class);
		AdDetails result=new AdDetails();
		
		for (AdDetails adDetails : details) {
			if(id.equals(adDetails.getGenUniqId()))
			{
				
				return adDetails;
			}
		}
			
		return result;
		
	}


	
	
	

	

	

}
