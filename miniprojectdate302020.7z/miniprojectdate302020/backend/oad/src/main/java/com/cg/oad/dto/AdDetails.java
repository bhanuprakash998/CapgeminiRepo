package com.cg.oad.dto;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="AdDetails")
public class AdDetails {
	@Id
	private String genUniqId;
	private long contactNo;
	private String emailId;
	private String name;
	private Double price;
	
	private String description;
	private String category;
	public AdDetails() {
		// TODO Auto-generated constructor stub
	}
	public String getGenUniqId() {
		return genUniqId;
	}
	public void setGenUniqId(String genUniqId) {
		this.genUniqId = genUniqId;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public AdDetails(String genUniqId, long contactNo, String emailId, String name, Double price, String description,
			String category) {
		super();
		this.genUniqId = genUniqId;
		this.contactNo = contactNo;
		this.emailId = emailId;
		this.name = name;
		this.price = price;
		this.description = description;
		this.category = category;
	}
	@Override
	public String toString() {
		return "AdDetails [genUniqId=" + genUniqId + ", contactNo=" + contactNo + ", emailId=" + emailId + ", name="
				+ name + ", price=" + price + ", description=" + description + ", category=" + category + "]";
	}
	
}
	