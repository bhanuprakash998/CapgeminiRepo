import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-delete',
  templateUrl: './admin-delete.component.html',
  styleUrls: ['./admin-delete.component.css']
})
export class AdminDeleteComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
 
  onSubmit(values)
{
  console.log(values.aname)
  if(values.aname=="admin"&&values.apass=="admin")
  {
    alert("correct credentials");
    this.router.navigate(['./deletepage']);
    }
  else{
    alert("wrong credentials");
  }

console.log(values);
}

}
