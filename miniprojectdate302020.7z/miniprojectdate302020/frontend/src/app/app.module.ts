import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegComponent } from './registration/reg.component';
import { from } from 'rxjs';
import { LoginComponent } from './registration/login.component';
import { PostingAdComponent } from './registration/posting-ad.component';
import{HttpClientModule} from '@angular/common/http';
import { MenuitemsComponent } from './menuitems.component';
import { DeleteAdComponent } from './delete-ad.component';
import { SearchAdComponent } from './search-ad.component';
import { GetAdDetailsComponent } from './get-ad-details.component';
import { UpdateaddComponent } from './updateadd.component';
import { GetAllComponent } from './get-all.component';
import { ReportAdComponent } from './report-ad.component';
import { AdminDeleteComponent } from './admin-delete.component';
import { UploadAdComponent } from './upload-ad/upload-ad.component'
@NgModule({
  declarations: [
    AppComponent,
    RegComponent,
    LoginComponent,
    PostingAdComponent,
    MenuitemsComponent,
    DeleteAdComponent,
    SearchAdComponent,
    GetAdDetailsComponent,
    UpdateaddComponent,
    GetAllComponent,
    ReportAdComponent,
    AdminDeleteComponent,
    UploadAdComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
