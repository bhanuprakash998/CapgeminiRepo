import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OnlineService } from '../service/online.service';

@Component({
  selector: 'app-posting-ad',
  templateUrl: './posting-ad.component.html',
  styleUrls: ['./posting-ad.component.css']
})
export class PostingAdComponent implements OnInit {
  values:any;
  constructor(private router:Router,private service:OnlineService) { }

  ngOnInit() {
  }
  onSubmit(values){
    console.log(values);
    this.service.addpostAd(values).subscribe();
 
  }
  onPost()
  {
    alert("--posted successfully--")
  }

}
