import { Component, OnInit } from '@angular/core';
import { OnlineService } from '../service/online.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload-ad',
  templateUrl: './upload-ad.component.html',
  styleUrls: ['./upload-ad.component.css']
})
export class UploadAdComponent implements OnInit {

  model:any={}
  selectedFiles: FileList; 
   currentFileUpload: File;
  constructor(private router:Router,private service:OnlineService) { }

  ngOnInit() {
  }
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
   upload() {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.service.uplaod(this.currentFileUpload).subscribe(event => {
      
    }); 
    this.selectedFiles = undefined;
  }
}
