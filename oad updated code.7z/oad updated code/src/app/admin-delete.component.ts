import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-admin-delete',
  templateUrl: './admin-delete.component.html',
  styleUrls: ['./admin-delete.component.css']
})
export class AdminDeleteComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
 
  onSubmit(values)
{
  console.log(values.aname)
  if(values.aname=="admin"&&values.apass=="admin")
  {
    Swal.fire(
      'Success!',
      'You have Logged In!',
      'success'
    )
    this.router.navigate(['./adminhome']);
    }
  else{
    Swal.fire(
      'Oops!',
      'You have entered wrong credentials!',
      'error'
    )
  }

console.log(values);
}

}
