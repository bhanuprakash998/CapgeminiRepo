import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './registration/login.component';
import { RegComponent } from './registration/reg.component';
import { PostingAdComponent } from './registration/posting-ad.component';
import { MenuitemsComponent } from './menuitems.component';
import { DeleteAdComponent } from './delete-ad.component';
import { SearchAdComponent } from './search-ad.component';
import { GetAdDetailsComponent } from './get-ad-details.component';
import { GetAllComponent } from './get-all.component';
import { ReportAdComponent } from './report-ad.component';
import { AdminDeleteComponent } from './admin-delete.component';
import { UpdateaddComponent } from './updateadd.component';
import { UploadAdComponent } from './upload-ad/upload-ad.component';
import { RUHomeComponent } from './ruhome.component';
import { VHomeComponent } from './vhome.component';
import { VSearchComponent } from './vsearch.component';
import { AdminContactComponent } from './admin-contact.component';
import { AdminHomeComponent } from './admin-home.component';


const routes: Routes = [
  {path:'loginpage',component:LoginComponent},
  {path:'registerpage',component:RegComponent},
  {path:'postpage',component:PostingAdComponent},
  {path:'menupage',component:MenuitemsComponent},
  {path:'deletepage',component:DeleteAdComponent},
  {path:'searchpage',component:SearchAdComponent},
  {path:'searchdetails',component:GetAdDetailsComponent},
  {path:'alldata',component:GetAllComponent},
  {path:'report',component:ReportAdComponent},
  {path:'admindelete',component:AdminDeleteComponent},
  {path:'update',component:UpdateaddComponent},
  {path:'upload',component:UploadAdComponent},
  {path:'rhome',component:RUHomeComponent},
  {path:'vhome',component:VHomeComponent},
  {path:'vsearch',component:VSearchComponent},
  {path:'admincontact',component:AdminContactComponent},
  {path:'adminhome',component:AdminHomeComponent}
 // {path :'', redirectTo:'/registerpage', pathMatch:'full'}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
