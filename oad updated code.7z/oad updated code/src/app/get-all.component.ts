import { Component, OnInit } from '@angular/core';
import { OnlineService } from './service/online.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-get-all',
  templateUrl: './get-all.component.html',
  styleUrls: ['./get-all.component.css']
})
export class GetAllComponent implements OnInit {
  samples:any[]=[];uid:any;Id:any
  constructor(private service:OnlineService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    //let id = this.route.snapshot.params['id']; 
   // console.log("in getall"+id)
    this.service.Getall().subscribe((data:any)=>{
      console.log(data);
      this.samples=data;
    })
   
    
  }
    OnClickId(values:any)
    {
      localStorage.setItem("uniqid",values);
      console.log(values);
    }
    
  }


