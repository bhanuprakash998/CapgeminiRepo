import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-click',
  templateUrl: './home-click.component.html',
  styleUrls: ['./home-click.component.css']
})
export class HomeClickComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
admin(){


this.router.navigate(['./admindelete']);

}
registeredUser(){
  this.router.navigate(['./loginpage']);
}
viewers(){
  this.router.navigate(['./vhome']);
}
}
