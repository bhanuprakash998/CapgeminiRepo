import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OnlineService } from '../service/online.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
model:any={}
result:boolean
  constructor(private router:Router,private service:OnlineService) { }

  ngOnInit() {
  }
  addUser(){
    console.log(this.model.mailId+this.model.password)
    this.service.verifyUser(this.model.mailId,this.model.password).subscribe((data:boolean)=>{
      this.result=data
      if(this.result)
      {
        Swal.fire(
          'Good job!',
          'You have logged in successfully!',
          'success'
        )
         this.router.navigate(['./rhome']);
      }
      else{
        Swal.fire(
          'Oops!',
          'You have entered wrong credentials!',
          'error'
        )
      }
    })
    
   
  }

}
