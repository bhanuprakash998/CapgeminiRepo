import { Component, OnInit } from '@angular/core';
import { OnlineService } from './service/online.service';

@Component({
  selector: 'app-report-ad',
  templateUrl: './report-ad.component.html',
  styleUrls: ['./report-ad.component.css']
})
export class ReportAdComponent implements OnInit {
uid:any;

  constructor(private service:OnlineService) { }

  ngOnInit() {
    this.uid=localStorage.getItem("uniqid");
    console.log("uniq id in report c"+this.uid);
  }
  onReport()
  {
    alert("successfully reported!")
  }
  onSubmit(values:any){
    
    console.log("dat in ts"+values.feedback);
    console.log("uid in "+this.uid);
   
    
    this.service.report(this.uid,values.feedback).subscribe();


    
 
  }
}
