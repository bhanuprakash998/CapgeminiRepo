import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http'
import { from, Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class OnlineService {

  constructor(private http:HttpClient) { }
  adduser(data:any){
    let input={"name":data.name,"emailId":data.mailId,"contactNo":data.phoneNumber,
    "password":data.password};
   
     return this.http.post("http://localhost:9999/register",input);
    
  }
  verifyUser(email,password)
  {
    return this.http.get("http://localhost:9999/verifyuser/"+email+"/"+password);
  }
  searchAd(category)
  {
    return this.http.get("http://localhost:9999/getad/"+category);
  }
  addpostAd(data:any){
    let input={"name":data.proname,"emailId":data.email,"genUniqId":data.uniqueid,
     "description":data.description,"category":data.cname,"price":data.pprice,"contactNo":data.cno}
 
 //console.log("---in service:"+input);
   return this.http.post("http://localhost:9999/postad",input);
     }
 DeleteAd(data)
 {
  console.log("---in service:"+data);
   return this.http.delete("http://localhost:9999/removead/"+data.uniqueid)
 }
 Getall()
 {
  return this.http.get("http://localhost:9999/getall");
 }
 report(id,des)
 {
   console.log("in service"+id+des);
  return this.http.post("http://localhost:9999/reportad/"+id+"/"+des,1);
 }
 getById(id:string){
   return this.http.get("http://localhost:9999/getbyId/"+id);

 }
 update(data:any){
  let input={"name":data.proname,"emailId":data.email,"genUniqId":data.uniqueid,
  "description":data.description,"category":data.cname,"price":data.pprice,"contactNo":data.cno}


   return this.http.put("http://localhost:9999/update",input)
 }
 uplaod(file: File):Observable<any>{
   
  const formdata=new FormData();
  
  let dat=formdata.append('file',file);

  return this.http.post("http://localhost:9999/upload",formdata,{
      reportProgress:true,responseType:'text'
    });
  
}
}
