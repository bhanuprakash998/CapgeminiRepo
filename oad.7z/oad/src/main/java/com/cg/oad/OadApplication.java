package com.cg.oad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OadApplication {

	public static void main(String[] args) {
		SpringApplication.run(OadApplication.class, args);
		//System.setProperty("tomcat.util.http.parser.HttpParser.requestTargetAllow", "{}");
     System.out.println("running");
	}

}
