import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MenuComponent } from './umsproject/menu/menu.component';
import { LoginComponent } from './umsproject/login.component';
import { LoadsingleComponent } from './umsproject/loadsingle/loadsingle.component';
import { SelectedtableComponent } from './umsproject/selectedtable/selectedtable.component';
import { LoadbulkComponent } from './umsproject/loadbulk/loadbulk.component';
import { ViewpageComponent } from './umsproject/viewpage/viewpage.component';
import { ModifyComponent } from './umsproject/modify/modify.component';
import { OldnewdataComponent } from './umsproject/oldnewdata/oldnewdata.component';
import { SignupComponent } from './umsproject/signup/signup.component';


const routes: Routes = [

  {path:'loginpage',component:LoginComponent},
  {path :'menupage',component:MenuComponent},
  {path :'loadsingle',component:LoadsingleComponent},
  {path:'selectedtablepage',component:SelectedtableComponent},
  {path:'loadbulk',component:LoadbulkComponent},
  {path:'viewpage',component:ViewpageComponent},
  {path:'modifypage',component:ModifyComponent},
  {path:'oldnewpage',component:OldnewdataComponent},
  {path:'signuppage',component:SignupComponent},
  {path :'', redirectTo:'/loginpage', pathMatch:'full'}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
