import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './umsproject/login.component';
import { MenuComponent } from './umsproject/menu/menu.component';
import { LoadsingleComponent } from './umsproject/loadsingle/loadsingle.component';
import { SelectedtableComponent } from './umsproject/selectedtable/selectedtable.component';
import { LoadbulkComponent } from './umsproject/loadbulk/loadbulk.component';
import { ViewpageComponent } from './umsproject/viewpage/viewpage.component';
import { ModifyComponent } from './umsproject/modify/modify.component';
import { OldnewdataComponent } from './umsproject/oldnewdata/oldnewdata.component';
import { SignupComponent } from './umsproject/signup/signup.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MenuComponent,
    LoadsingleComponent,
    SelectedtableComponent,
    LoadbulkComponent,
    ViewpageComponent,
    ModifyComponent,
    OldnewdataComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
