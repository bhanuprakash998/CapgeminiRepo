import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loadbulk',
  templateUrl: './loadbulk.component.html',
  styleUrls: ['./loadbulk.component.css']
})
export class LoadbulkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
