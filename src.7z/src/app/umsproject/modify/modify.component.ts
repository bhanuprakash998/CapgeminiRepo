import { Component, OnInit } from '@angular/core';
import{Router,RouterLink} from '@angular/router'
@Component({
  selector: 'app-modify',
  templateUrl: './modify.component.html',
  styleUrls: ['./modify.component.css']
})
export class ModifyComponent implements OnInit {
  router: any;



  constructor() { }

  ngOnInit() {
  }
myclick(event){
  
  this.router.navigate['./oldnewnpage'];
}
  

}
