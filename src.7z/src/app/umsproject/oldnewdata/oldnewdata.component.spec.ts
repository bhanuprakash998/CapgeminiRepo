import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OldnewdataComponent } from './oldnewdata.component';

describe('OldnewdataComponent', () => {
  let component: OldnewdataComponent;
  let fixture: ComponentFixture<OldnewdataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OldnewdataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OldnewdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
