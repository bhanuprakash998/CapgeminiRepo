import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oldnewdata',
  templateUrl: './oldnewdata.component.html',
  styleUrls: ['./oldnewdata.component.css']
})
export class OldnewdataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
