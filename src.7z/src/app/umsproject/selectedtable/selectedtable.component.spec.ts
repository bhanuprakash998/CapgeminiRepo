import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedtableComponent } from './selectedtable.component';

describe('SelectedtableComponent', () => {
  let component: SelectedtableComponent;
  let fixture: ComponentFixture<SelectedtableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectedtableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedtableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
