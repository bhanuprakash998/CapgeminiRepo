import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selectedtable',
  templateUrl: './selectedtable.component.html',
  styleUrls: ['./selectedtable.component.css']
})
export class SelectedtableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
