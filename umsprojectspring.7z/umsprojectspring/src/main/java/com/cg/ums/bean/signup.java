package com.cg.ums.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class signup {
	@Id
	@Column(name = "eid", unique = true, nullable = false)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	private Integer eid;
private String firstname;
private String lastname;
private String phone;
@JsonFormat(pattern = "mm-dd-yyyy")
private Date birtdate;
private String gender;
private String email;
private String password;
private String confirmpassword;
public signup() {
	super();
}
public signup(String firstname, String lastname, String phone, Date birtdate, String gender, String email,
		String password, String confirmpassword) {
	super();
	this.firstname = firstname;
	this.lastname = lastname;
	this.phone = phone;
	this.birtdate = birtdate;
	this.gender = gender;
	this.email = email;
	this.password = password;
	this.confirmpassword = confirmpassword;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public Date getBirtdate() {
	return birtdate;
}
public void setBirtdate(Date birtdate) {
	this.birtdate = birtdate;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getConfirmpassword() {
	return confirmpassword;
}
public void setConfirmpassword(String confirmpassword) {
	this.confirmpassword = confirmpassword;
}
@Override
public String toString() {
	return "signup [firstname=" + firstname + ", lastname=" + lastname + ", phone=" + phone + ", birtdate=" + birtdate
			+ ", gender=" + gender + ", email=" + email + ", password=" + password + ", confirmpassword="
			+ confirmpassword + "]";
}

}
