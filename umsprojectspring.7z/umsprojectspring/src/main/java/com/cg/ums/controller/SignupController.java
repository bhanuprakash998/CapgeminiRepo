package com.cg.ums.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ums.bean.Courses;
import com.cg.ums.bean.signup;
import com.cg.ums.service.CourseInterface;
import com.cg.ums.service.Signupservice;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class SignupController {
	@Autowired
   Signupservice service;
	@PostMapping("/adddata")
public signup adddata(@RequestBody signup sign) {
	return service.add(sign);
}
	
}
