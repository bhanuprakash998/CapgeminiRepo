package com.cg.ums.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ums.bean.College;
import com.cg.ums.service.UnivercityServiceInterface;

@RestController
@RequestMapping("/college")
//@CrossOrigin(origins="http://localhost:4200")
public class UnivercityController {
	@Autowired
	private UnivercityServiceInterface  uservice;
	@RequestMapping(value ="/savecollege", method = RequestMethod.POST)
	public List<College> createProduct(@RequestBody College college) {
		return  uservice.saveCollegeData(college);
	}
	@RequestMapping(value = "/getcollegedetails", method = RequestMethod.GET)
	public List<College> getAllProducts() {
		return  uservice.getCollegeDetails();
	} 
	@RequestMapping(value = "/updatecollege", method = RequestMethod.POST)
	public College updateCollege(@RequestBody College college) {
		return  uservice.updatecollege(college);
	}
	
	@RequestMapping(value="/searchcollege/{eid}",method=RequestMethod.GET)
	
	public College searchcollege(@PathVariable("eid") Integer collegeid)
	{
		return uservice.searchbycollegeid(collegeid);
		
	}
	@RequestMapping(value = "/deletecollege/{cid}", method = RequestMethod.DELETE)
	public void delProduct(@PathVariable("cid") Integer cid) {
		uservice.deletecollege(cid);
	 
	}
	@DeleteMapping("/deletetable")
	public String truncateMyTable() {
		uservice.truncateMyCollege();
		return "deleted";
	}
}
