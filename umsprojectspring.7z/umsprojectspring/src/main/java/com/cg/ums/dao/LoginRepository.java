package com.cg.ums.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ums.bean.Login;

public interface LoginRepository extends JpaRepository<Login,Integer> {
	//public Login search(Integer eid,String username,String password); 
}
