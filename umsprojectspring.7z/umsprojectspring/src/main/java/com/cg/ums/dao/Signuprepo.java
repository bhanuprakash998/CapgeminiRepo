package com.cg.ums.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ums.bean.signup;
@Repository
public interface Signuprepo extends JpaRepository<signup,Integer>{

}
