package com.cg.ums.dao;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.ums.bean.College;



@Repository
public interface UnivercityRepository extends JpaRepository<College, Integer> {

	@Modifying
    @Query(
            value = "truncate table College",
            nativeQuery = true
    )
    void truncateMyCollege();


}
