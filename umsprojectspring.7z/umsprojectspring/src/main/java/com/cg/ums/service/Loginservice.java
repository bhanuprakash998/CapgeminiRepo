package com.cg.ums.service;

import com.cg.ums.bean.Login;

public interface Loginservice {
public Login search(Integer eid,String username,String password);
}
