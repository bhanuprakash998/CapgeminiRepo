package com.cg.ums.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ums.bean.Login;
import com.cg.ums.dao.LoginRepository;

public class LoginserviceImpl implements Loginservice{
    @Autowired
	LoginRepository repo;
	@Override
	public Login search(Integer id,String username, String password) {
		// TODO Auto-generated method stub
	    repo.findById(id);
		
		return null;
	}

}
