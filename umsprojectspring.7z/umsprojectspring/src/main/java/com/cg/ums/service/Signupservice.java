package com.cg.ums.service;


import com.cg.ums.bean.signup;

public interface Signupservice {
	signup add(signup su);
}
