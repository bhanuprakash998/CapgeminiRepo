package com.cg.ums.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ums.bean.signup;
import com.cg.ums.dao.Signuprepo;
@Service
public class SignupserviceImpl implements Signupservice{
    @Autowired
	Signuprepo repo;
	@Override
	public signup add(signup su) {
		
		return repo.save(su);
	}

}
