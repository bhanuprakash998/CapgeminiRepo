package com.cg.ums.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ums.bean.College;
import com.cg.ums.bean.Login;
import com.cg.ums.dao.LoginRepository;
import com.cg.ums.dao.UnivercityRepository;
@Service
public class UnivercityServiceImpl implements UnivercityServiceInterface{
      @Autowired
	 UnivercityRepository unirepo;
    @Autowired  
  	LoginRepository loginrepo;

	@Override
	public List<College> saveCollegeData(College college) {
		unirepo.save(college);
		return unirepo.findAll();
	}

	@Override
	public List<College> getCollegeDetails() {
	
		return unirepo.findAll();
	}

	@Override
	public College updatecollege(College college) {
		return unirepo.save(college);
		
	}

	@Override
	public Login doLoginsave(Login log) {
	
		return loginrepo.save(log);
	}

	@Override
	public College searchbycollegeid(Integer collegeid) {
	College id=unirepo.findById(collegeid).get();
	return id;
	}

	@Override
	public void deletecollege(Integer cid) {
		unirepo.deleteById(cid);
		
	}
	

	@Override
	@Transactional
	public void truncateMyCollege() {
		unirepo.truncateMyCollege();
		
	}
	

}
