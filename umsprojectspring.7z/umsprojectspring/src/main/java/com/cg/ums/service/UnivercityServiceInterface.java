package com.cg.ums.service;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.ums.bean.College;
import com.cg.ums.bean.Login;


public interface UnivercityServiceInterface {

	List<College>saveCollegeData(College college);

	List<College> getCollegeDetails();

	College updatecollege(College college);
	
	Login doLoginsave(Login log);

	College searchbycollegeid(Integer collegeid);

	void deletecollege(Integer cid);
    public void truncateMyCollege();
} 

